=== Hello Worthy ===

A test plugin based on the Hello Dolly WordPress plugin

== Description ==

When activated you will randomly see a comment, quote, phrase or lyric in the upper right of your admin screen on every page. This is based on the Hello Dolly plugin that comes as a standard install of all WordPress installations. Instead of lyrics to the song Hello, Dolly, this plugin will display a quote, reminder or other comment. 

This plugin is essentially pointless but is good practice for me. 


